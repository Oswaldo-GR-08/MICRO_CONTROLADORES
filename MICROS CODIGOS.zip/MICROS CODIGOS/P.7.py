# ============================================================================
# Práctica 7: Contador Binario Ascendente de 4 Bits con Pull-down Interno
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import Pin
import time

# --- CONFIGURACIÓN DE HARDWARE ---
# Arreglo de pines para los 4 LEDs (Desde el Bit Menos Significativo LSB al Más Significativo MSB)
# Conexiones sugeridas: GP2 (Bit 0), GP3 (Bit 1), GP4 (Bit 2), GP5 (Bit 3)
PINES_LEDS = [2, 3, 4, 5]
leds = [Pin(pin, Pin.OUT) for pin in PINES_LEDS]

# Pulsador configurado como entrada con resistencia PULL_DOWN interna activa
# Esto asegura un '0' lógico estable mientras el botón esté en reposo
BUTTON_PIN = 6
pulsador = Pin(BUTTON_PIN, Pin.IN, Pin.PULL_DOWN)

# --- VARIABLES DE CONTROL ---
contador = 0
ultimo_estado_boton = 0

# --- FUNCIÓN PARA MOSTRAR EL VALOR EN BINARIO ---
def mostrar_en_leds(valor):
    """Descompone el número entero en sus componentes binarios de 4 bits"""
    for i in range(4):
        # Desplazamiento de bits y máscara para obtener el estado de cada bit (0 o 1)
        estado_bit = (valor >> i) & 1
        leds[i].value(estado_bit)

# Inicializar los LEDs apagados (Contador en 0)
mostrar_en_leds(contador)

print("[SISTEMA] Inicializado correctamente.")
print("[INFO] Resistencia Pull-down interna activada por software.")
print("[INFO] Contador listo en 0. Presiona el pulsador para incrementar.")

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    estado_actual_boton = pulsador.value()
    
    # Detectar flanco de subida (Transición de reposo '0' a presionado '1')
    if estado_actual_boton == 1 and ultimo_estado_boton == 0:
        
        # --- CONTROL DE REBOTES (DEBOUNCE) POR SOFTWARE ---
        time.sleep_ms(20) # Pausa de estabilización para filtrar ruido mecánico
        if pulsador.value() == 1: # Confirmar si el botón sigue realmente presionado
            
            contador += 1  # Incrementar la cuenta
            
            # Validación del límite del contador (0 a 15)
            # Al llegar a 16 (10000 binario), se reinicia automáticamente a 0
            if contador > 15:
                contador = 0
                
            print(f"[CONTEO] Valor: {contador} | Binario: {contador:04b}")
            mostrar_en_leds(contador)
            
            # Bloqueo de ciclo de espera: evita que el contador incremente ráfagas
            # si dejas el botón presionado continuamente
            while pulsador.value() == 1:
                time.sleep_ms(10)
                
    # Actualizar el registro del último estado del botón
    ultimo_estado_boton = estado_actual_boton
    time.sleep_ms(10)