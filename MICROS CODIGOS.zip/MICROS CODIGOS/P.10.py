# ============================================================================
# Práctica 10: Conversión Analógica-Digital (ADC) con Potenciómetro
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import ADC, Pin
import time

# --- CONFIGURACIÓN DE HARDWARE ---
# Se utiliza el canal ADC0 de la placa, el cual está mapeado en el pin GP26
ADC_PIN = 26
potenciometro = ADC(Pin(ADC_PIN))

print("[SISTEMA] Inicializado correctamente.")
print("[SERIAL] Leyendo datos desde el canal ADC0 (GP26)...")
print("-" * 50)

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    # 1. LEER EL VALOR DEL ADC
    # MicroPython lee el ADC con una resolución escalada a 16 bits (0 a 65535)
    lectura_16bits = potenciometro.read_u16()
    
    # 2. CONVERTIR A LA RESOLUCIÓN NATIVA DE 12 BITS (Especificada en el reporte)
    # Desplazamos 4 bits a la derecha (65535 >> 4 = 4095) para simular el ADC de 12 bits
    lectura_12bits = lectura_16bits >> 4
    
    # 3. CALCULAR EL VOLTAJE EQUIVALENTE
    # El rango de voltaje de referencia del ADC en la Pico W es de 0V a 3.3V
    voltaje = (lectura_12bits * 3.3) / 4095
    
    # 4. ENVIAR DATOS AL MONITOR SERIAL (Depuración en tiempo real)
    # Imprime el valor cuantizado de 12 bits y su representación en voltaje con 2 decimales
    print(f"[SERIAL] Valor ADC (12-bits): {lectura_12bits:4d} | Voltaje: {voltaje:.2f} V")
    
    # Pausa de muestreo de 200ms para asegurar una visualización fluida y estable
    time.sleep_ms(200)