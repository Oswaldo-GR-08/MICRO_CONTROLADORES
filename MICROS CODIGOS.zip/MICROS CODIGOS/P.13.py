# ============================================================================
# Práctica 13: Control de Velocidad y Sentido de Giro de Motor CC con L298N
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import Pin, PWM
import sys
import time

# --- CONFIGURACIÓN DE HARDWARE (Puente H L298N) ---
# Frecuencia estándar de 1000 Hz para el control PWM del motor CC
FRECUENCIA_MOTOR = 1000

# Pines de dirección (Entradas IN1 e IN2 del L298N)
IN1 = Pin(14, Pin.OUT)
IN2 = Pin(15, Pin.OUT)

# Pin de habilitación de velocidad (Entrada ENA del L298N)
ENA = PWM(Pin(16, Pin.OUT))
ENA.freq(FRECUENCIA_MOTOR)

# --- CONFIGURACIÓN DE ESTADO INICIAL ---
# Motor detenido en reposo al arrancar el microcontrolador
IN1.value(0)
IN2.value(0)
ENA.duty_u16(0)

print("[SISTEMA] Firmware de control para Puente H L298N Inicializado.")
print("[SERIAL] Esperando comandos desde la interfaz gráfica de Python...")
print("-" * 60)

# --- BUCLE PRINCIPAL DE EJECUCIÓN (Procesamiento Serial) ---
while True:
    # Verificar de forma no bloqueante si hay bytes disponibles en el puerto serial
    # sys.stdin.any() se usa para verificar datos de entrada por el canal USB STDIO
    if sys.stdin.any():
        # Leer la línea de comando enviada por la interfaz y limpiarla
        linea = sys.stdin.readline().strip()
        
        # Omitir tramas vacías o de ruido
        if not linea:
            continue
            
        try:
            # Las tramas esperadas tienen el formato "DIRECCION,VELOCIDAD" (Ej: "1,75" o "0,50")
            partes = linea.split(',')
            if len(partes) == 2:
                direccion = int(partes[0])  # 1 = Horario, 0 = Antihorario
                velocidad = int(partes[1])  # Porcentaje de velocidad (0 a 100)
                
                # --- 1. PROCESAR DIRECCIÓN DE GIRO ---
                if velocidad == 0:
                    # Paro de emergencia o inercia si la velocidad es cero
                    IN1.value(0)
                    IN2.value(0)
                    modo_giro = "DETENIDO"
                elif direccion == 1:
                    # Sentido horario (IN1=1, IN2=0)
                    IN1.value(1)
                    IN2.value(0)
                    modo_giro = "HORARIO"
                elif direccion == 0:
                    # Sentido antihorario (IN1=0, IN2=1)
                    IN1.value(0)
                    IN2.value(1)
                    modo_giro = "ANTIHORARIO"
                
                # --- 2. PROCESAR VELOCIDAD MEDIANTE PWM ---
                # Limitar el porcentaje entre 0 y 100 por seguridad
                velocidad = max(0, min(100, velocidad))
                
                # Convertir el porcentaje de velocidad (0-100%) al duty cycle de MicroPython (0-65535)
                ciclo_trabajo = int((velocidad * 65535) / 100)
                ENA.duty_u16(ciclo_trabajo)
                
                # Retroalimentación hacia la consola o puerto serial para depuración
                print(f"[ACCION] Estado: {modo_giro} | Velocidad aplicada: {velocidad}%")
                
        except Exception as e:
            # Captura de errores en caso de recibir una trama corrupta o mal formateada
            print(f"[ERROR] No se pudo decodificar la trama serial: {e}")
            
    # Pequeña pausa para no saturar el núcleo de procesamiento
    time.sleep_ms(10)