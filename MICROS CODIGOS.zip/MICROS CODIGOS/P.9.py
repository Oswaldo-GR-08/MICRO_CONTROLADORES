# ============================================================================
# Práctica 9: Conteo Multiplexado (00-99) con Cambio de Sentido por Pulsador
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import Pin
import time

# --- CONFIGURACIÓN DE HARDWARE ---
# Pines compartidos para los segmentos del display [A, B, C, D, E, F, G]
PINES_SEGMENTOS = [2, 3, 4, 5, 6, 7, 8]
segmentos = [Pin(pin, Pin.OUT) for pin in PINES_SEGMENTOS]

# Pines de control para la activación de cada dígito (Cátodos a transistores)
DIGITO_DECENAS = Pin(10, Pin.OUT)
DIGITO_UNIDADES = Pin(11, Pin.OUT)

# Pulsador configurado con resistencia Pull-up interna
BUTTON_PIN = 12
pulsador = Pin(BUTTON_PIN, Pin.IN, Pin.PULL_UP)

# --- MATRIZ DE DECODIFICACIÓN (7 Segmentos - Cátodo Común) ---
NUMEROS_7SEG = [
    [1, 1, 1, 1, 1, 1, 0],  # 0
    [0, 1, 1, 0, 0, 0, 0],  # 1
    [1, 1, 0, 1, 1, 0, 1],  # 2
    [1, 1, 1, 1, 0, 0, 1],  # 3
    [0, 1, 1, 0, 0, 1, 1],  # 4
    [1, 0, 1, 1, 0, 1, 1],  # 5
    [1, 0, 1, 1, 1, 1, 1],  # 6
    [1, 1, 1, 0, 0, 0, 0],  # 7
    [1, 1, 1, 1, 1, 1, 1],  # 8
    [1, 1, 1, 1, 0, 1, 1]   # 9
]

# --- VARIABLES DE CONTROL DE ESTADO ---
contador = 0
sentido_ascendente = True  # True = Ascendente, False = Descendente
ultimo_estado_boton = 1

# Variables para el control de tiempos (No bloqueantes para el multiplexado)
ultimo_cambio_conteo = time.ticks_ms()
intervalo_conteo = 200     # Velocidad del incremento/decremento (en ms)

# --- RUTINA DE MULTIPLEXADO (PERSISTENCIA DE LA VISIÓN) ---
def mostrar_numero(valor):
    """Separa el número en decenas/unidades y los conmuta rápidamente"""
    decenas = valor // 10
    unidades = valor % 10

    # --- PINTAR DÍGITO DE LAS DECENAS ---
    mapa_decenas = NUMEROS_7SEG[decenas]
    for i in range(7):
        segmentos[i].value(mapa_decenas[i])
    DIGITO_DECENAS.value(1)   # Encender cátodo de decenas
    DIGITO_UNIDADES.value(0)  # Apagar unidades
    time.sleep_ms(5)          # Retardo de conmutación (100Hz aproximados)

    # --- PINTAR DÍGITO DE LAS UNIDADES ---
    mapa_unidades = NUMEROS_7SEG[unidades]
    for i in range(7):
        segmentos[i].value(mapa_unidades[i])
    DIGITO_DECENAS.value(0)   # Apagar decenas
    DIGITO_UNIDADES.value(1)  # Encender cátodo de unidades
    time.sleep_ms(5)          # Retardo de conmutación

print("[SISTEMA] Multiplexación Inicializada.")
print("[SERIAL] Modo: Ascendente | Valor Inicial: 00")

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    tiempo_actual = time.ticks_ms()
    estado_actual_boton = pulsador.value()

    # 1. DETECCIÓN DEL PULSADOR (Cambio de sentido en flanco de bajada)
    if estado_actual_boton == 0 and ultimo_estado_boton == 1:
        time.sleep_ms(15)  # Anti-rebote rápido
        if pulsador.value() == 0:
            sentido_ascendente = not sentido_ascendente  # Invertir bandera de dirección
            modo_str = "Ascendente" if sentido_ascendente else "Descendente"
            print(f"[SERIAL] Sentido invertido por pulsador -> Modo: {modo_str}")
            
            # Espera a liberar el botón sin congelar completamente el display
            while pulsador.value() == 0:
                mostrar_numero(contador)

    ultimo_estado_boton = estado_actual_boton

    # 2. SEGUIMIENTO AUTOMÁTICO DEL CONTEO (Temporización No Bloqueante)
    if time.ticks_diff(tiempo_actual, ultimo_cambio_conteo) >= intervalo_conteo:
        if sentido_ascendente:
            contador += 1
            if contador > 99:
                contador = 0
        else:
            contador -= 1
            if contador < 0:
                contador = 99
        
        # Imprimir de forma síncrona en el monitor serial
        print(f"[SERIAL] Conteo actual: {contador:02d}")
        ultimo_cambio_conteo = tiempo_actual

    # 3. EJECUCIÓN CONTINUA DEL MULTIPLEXADO
    mostrar_numero(contador)