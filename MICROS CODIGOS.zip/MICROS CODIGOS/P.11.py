# ============================================================================
# Práctica 11: Sistema de Monitoreo y Control Térmico con LM35 y Ventilador
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import ADC, Pin
import time

# --- CONFIGURACIÓN DE HARDWARE ---
# Canal ADC0 (GP26) para leer el voltaje analógico del LM35
LM35_PIN = 26
sensor_temperatura = ADC(Pin(LM35_PIN))

# Pin digital GP15 configurado como salida para controlar la base del transistor 2N2222A
VENTILADOR_PIN = 15
ventilador = Pin(VENTILADOR_PIN, Pin.OUT)

# --- CONFIGURACIÓN DE PARÁMETROS ---
UMBRAL_TEMPERATURA = 30.0  # Umbral de activación en °C (Ajustable)

# Asegurar que el ventilador inicie apagado
ventilador.value(0)

print("[SISTEMA] Inicializado correctamente.")
print(f"[CONFIG] Umbral de activación del ventilador: {UMBRAL_TEMPERATURA}°C")
print("-" * 60)

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    # 1. LEER EL ADC DE 16 BITS (0 a 65535)
    lectura_adc = sensor_temperatura.read_u16()
    
    # 2. CALCULAR EL VOLTAJE EN MILIVOLTIOS (mV)
    # Voltaje de referencia de la Pico W = 3.3V (3300 mV)
    voltaje_mv = (lectura_adc * 3300.0) / 65535.0
    
    # 3. CONVERTIR VOLTAJE A TEMPERATURA EN CELSIUS (°C)
    # El LM35 tiene un factor de escala lineal de 10 mV por cada grado Celsius (10mV/°C)
    temperatura = voltaje_mv / 10.0
    
    # 4. SISTEMA DE LAZO DE CONTROL (ON/OFF)
    if temperatura >= UMBRAL_TEMPERATURA:
        if ventilador.value() == 0:
            ventilador.value(1)  # Activar transistor -> Encender ventilador
            print("[ALERTA] Umbral superado. Ventilador ACTIVADO.")
    else:
        if ventilador.value() == 1:
            ventilador.value(0)  # Desactivar transistor -> Apagar ventilador
            print("[INFO] Temperatura normalizada. Ventilador APAGADO.")
            
    # 5. TRANSMISIÓN DE DATOS SERIALES
    # Formato síncrono ideal para ser decodificado por el script "Grafica.py"
    print(f"Temperatura:{temperatura:.2f}C")
    
    # Muestreo cada 500 milisegundos para mantener lecturas térmicas estables
    time.sleep_ms(500)