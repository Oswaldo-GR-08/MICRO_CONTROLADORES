# ============================================================================
# Práctica 6: Configuración de GPIO como Entrada Digital (Pulsador y LED)
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import Pin
import time

# --- CONFIGURACIÓN DE HARDWARE ---
# LED verde configurado como salida en el pin GP3
LED_PIN = 3
led = Pin(LED_PIN, Pin.OUT)

# Pulsador configurado como entrada en el pin GP4
# Nota: Dado que el circuito físico ya incluye su propia resistencia 
# pull-down externa de 10k, se define simplemente como Pin.IN
BUTTON_PIN = 4
pulsador = Pin(BUTTON_PIN, Pin.IN)

print("[SISTEMA] Inicializado correctamente.")
print("[INFO] Presiona el pulsador físico para encender el LED verde.")

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    # Leer el estado de la entrada digital (GP4)
    # Retorna 1 si el pulsador está presionado (3.3V) o 0 si está en reposo (0V)
    if pulsador.value() == 1:
        led.value(1)  # Estado Activo: Encender LED (3.3V)
    else:
        led.value(0)  # Estado de Reposo: Apagar LED (0V)
    
    # Breve pausa de estabilidad para el ciclo de lectura (evita el rebote lógico)
    time.sleep_ms(10)