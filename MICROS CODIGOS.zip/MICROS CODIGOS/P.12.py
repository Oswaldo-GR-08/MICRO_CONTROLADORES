# ============================================================================
# Práctica 12: Control de LED RGB mediante Mezcla de Color con ADC y PWM
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import ADC, Pin, PWM
import time

# --- CONFIGURACIÓN DE CANALES PWM (Salidas al LED RGB) ---
# Frecuencia fija estándar de 1000 Hz para el control de los LEDs
FRECUENCIA_PWM = 1000

PWM_R = PWM(Pin(16, Pin.OUT))  # GP16 para el ánodo/canal Rojo
PWM_G = PWM(Pin(17, Pin.OUT))  # GP17 para el ánodo/canal Verde
PWM_B = PWM(Pin(18, Pin.OUT))  # GP18 para el ánodo/canal Azul

PWM_R.freq(FRECUENCIA_PWM)
PWM_G.freq(FRECUENCIA_PWM)
PWM_B.freq(FRECUENCIA_PWM)

# --- CONFIGURACIÓN DE ENTRADAS ANALÓGICAS (Potenciómetros) ---
ADC_R = ADC(Pin(26))  # ADC0 (GP26) -> Control de canal Rojo
ADC_G = ADC(Pin(27))  # ADC1 (GP27) -> Control de canal Verde
ADC_B = ADC(Pin(28))  # ADC2 (GP28) -> Control de canal Azul

# --- CONSTANTE DE ENLACE ---
# Valor de Wrap/Límite de resolución para 12 bits (0 a 4095)
PWM_WRAP_VAL = 4095.0

print("[SISTEMA] Control PWM-ADC para LED RGB Inicializado.")
print("-" * 60)

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    # 1. LEER CANALES DEL ADC Y ESCALARLOS A 12 BITS (Rango 0 - 4095)
    # MicroPython entrega nativamente 16 bits (0-65535), aplicamos desplazamiento de 4 bits
    val_r = ADC_R.read_u16() >> 4
    val_g = ADC_G.read_u16() >> 4
    val_b = ADC_B.read_u16() >> 4
    
    # 2. ACTUALIZAR LOS CICLOS DE TRABAJO DEL PWM
    # Escalamos el valor de 12 bits de regreso a la resolución de ciclo de MicroPython (16 bits)
    # para inyectarlo de forma proporcional a los pines correspondientes
    PWM_R.duty_u16(val_r << 4)
    PWM_G.duty_u16(val_g << 4)
    PWM_B.duty_u16(val_b << 4)
    
    # 3. CALCULAR PORCENTAJES PARA EL DESPLIEGUE EN EL MONITOR SERIAL
    pct_r = (val_r * 100.0) / PWM_WRAP_VAL
    pct_g = (val_g * 100.0) / PWM_WRAP_VAL
    pct_b = (val_b * 100.0) / PWM_WRAP_VAL
    
    # 4. DESPLIEGUE CON EL FORMATO SOLICITADO EN LA GUÍA
    print("Canales_de_color:")
    print(f"R: {pct_r:.1f}% | G: {pct_g:.1f}% | B: {pct_b:.1f}%\n")
    
    # Pausa de 500ms especificada para estabilización y lectura clara del puerto serial
    time.sleep_ms(500)