// ============================================================================
// Práctica 5: Uso de los pines de propósito general de entrada/salida (GPIO)
// Desarrollado por: OGRI
// Plataforma: Raspberry Pi Pico W (Lenguaje C)
// ============================================================================

#include "pico/stdlib.h"

int main() {
    // Pin GP3 definido para el LED en la práctica
    const uint LED_PIN = 3; 
    
    // Inicialización del pin GPIO
    gpio_init(LED_PIN);
    
    // Configurar el pin como salida (GPIO_OUT)
    gpio_set_dir(LED_PIN, GPIO_OUT);
    
    // Bucle principal para el parpadeo de 250ms
    while (true) {
        gpio_put(LED_PIN, 1); // Encender LED (3.3V)
        sleep_ms(250);        // Retardo de 250ms
        
        gpio_put(LED_PIN, 0); // Apagar LED (0V)
        sleep_ms(250);        // Retardo de 250ms
    }
}