# ============================================================================
# Práctica 17: Sistema de Mensajería Local Inalámbrico (Servidor Web AP)
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

import network
import socket
import time
from machine import Pin

# --- CONFIGURACIÓN DEL ACCESS POINT (RED WI-FI) ---
AP_SSID     = "ChatPico"       
AP_PASSWORD = "pico1234"       
AP_IP        = "192.168.4.1"    

# Indicador óptico en placa
led_onboard = Pin("LED", Pin.OUT)   

# Memoria volátil para el almacenamiento de mensajes
mensajes = []
MAX_MENSAJES = 100   

def hora_actual():
    """Genera una estampa de tiempo relativa en formato HH:MM:SS"""
    t = time.ticks_ms() // 1000
    h = (t // 3600) % 24
    m = (t % 3600) // 60
    s = t % 60
    return f"{h:02d}:{m:02d}:{s:02d}"

def url_decode(texto):
    """Decodifica caracteres especiales y espacios de la trama HTTP"""
    texto = texto.replace("+", " ")
    i = 0
    resultado = ""
    while i < len(texto):
        if texto[i] == "%" and i + 2 < len(texto):
            try:
                resultado += chr(int(texto[i+1:i+3], 16))
                i += 3
            except:
                resultado += texto[i]
                i += 1
        else:
            resultado += texto[i]
            i += 1
    return resultado

def parsear_post(body):
    """Extrae las variables del cuerpo de una petición HTTP POST"""
    params = {}
    for par in body.split("&"):
        if "=" in par:
            k, v = par.split("=", 1)
            params[url_decode(k)] = url_decode(v)
    return params

def sanitizar(texto, max_len=200):
    """Filtra caracteres especiales para prevenir inyección de código HTML"""
    texto = texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return texto[:max_len].strip()

def iniciar_ap():
    """Inicializa la interfaz de red en modo Punto de Acceso"""
    ap = network.WLAN(network.AP_IF)
    ap.active(True)
    # Configuración de red con cifrado WPA2 (authmode=3)
    ap.config(essid=AP_SSID, password=AP_PASSWORD, authmode=3)  
    
    # Configurar IP estática, máscara de red, gateway y DNS
    ap.ifconfig((AP_IP, "255.255.255.0", AP_IP, "8.8.8.8"))
    
    while not ap.active():
        time.sleep(0.1)
        
    print("[SISTEMA] Punto de Acceso activado exitosamente.")
    print(f"[RECONEXIÓN] Conéctate a la red '{AP_SSID}' e ingresa a http://{AP_IP}")
    led_onboard.value(1) # LED encendido fijo indica red lista
    return ap

def pagina_html(usuario_actual=""):
    """Genera dinámicamente la interfaz gráfica HTML y los estilos embebidos"""
    items_html = ""
    # Desplegar los últimos 50 mensajes en orden inverso (más recientes abajo)
    for m in reversed(mensajes[-50:]):   
        es_mio = (m["usuario"] == usuario_actual and usuario_actual != "")
        alineacion = "derecha" if es_mio else "izquierda"
        color_burbuja = "#0084ff" if es_mio else "#3a3a4a"
        
        items_html += f"""
        <div class="mensaje {alineacion}">
          <div class="burbuja" style="background:{color_burbuja}">
            <span class="nombre">{m['usuario']}</span>
            <p>{m['texto']}</p>
            <span class="hora">{m['hora']}</span>
          </div>
        </div>"""

    if not items_html:
        items_html = '<p class="vacio">Aún no hay mensajes en la sala.</p>'

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chat Pico - Local</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: -apple-system, sans-serif; background: #131324; color: #eee; max-width: 500px; margin: 0 auto; display: flex; flex-direction: column; height: 100vh; }}
    header {{ background: #1a1a2e; padding: 15px; text-align: center; border-bottom: 2px solid #0f3460; font-weight: bold; color: #0084ff; }}
    .chat-area {{ flex: 1; padding: 14px; display: flex; flex-direction: column-reverse; gap: 10px; overflow-y: auto; }}
    .mensaje {{ display: flex; width: 100%; }}
    .mensaje.izquierda {{ justify-content: flex-start; }}
    .mensaje.derecha {{ justify-content: flex-end; }}
    .burbuja {{ max-width: 80%; padding: 10px 14px; border-radius: 18px; position: relative; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }}
    .mensaje.izquierda .burbuja {{ border-bottom-left-radius: 4px; }}
    .mensaje.derecha .burbuja {{ border-bottom-right-radius: 4px; }}
    .nombre {{ font-size: 0.75rem; color: #00ffff; font-weight: bold; display: block; margin-bottom: 2px; }}
    .mensaje.derecha .nombre {{ color: #ffeb3b; }}
    p {{ font-size: 0.95rem; word-break: break-word; line-height: 1.3; }}
    .hora {{ font-size: 0.65rem; color: #aaa; display: block; text-align: right; margin-top: 4px; }}
    .vacio {{ text-align: center; color: #666; margin-top: 20px; font-style: italic; }}
    form {{ display: flex; gap: 8px; padding: 12px; background: #16213e; border-top: 1px solid #0f3460; }}
    .in-user {{ width: 30%; background: #1a1a2e; color: #eee; padding: 12px; border: 1px solid #0f3460; border-radius: 22px; text-align: center; font-weight: bold; }}
    .in-text {{ flex: 1; background: #1a1a2e; color: #eee; padding: 12px 18px; border: 1px solid #0f3460; border-radius: 22px; }}
    button {{ background: #0084ff; color: white; border: none; width: 44px; height: 44px; border-radius: 50%; font-size: 1.1rem; cursor: pointer; transition: background 0.2s; }}
    button:active {{ background: #0056b3; }}
  </style>
</head>
<body>
  <header>📡 SALA DE CHAT LOCAL PICO W</header>
  <div class="chat-area" id="chat">{items_html}</div>
  <form action="/enviar" method="post" id="chatForm">
    <input name="usuario" id="userField" class="in-user" type="text" placeholder="Apodo" value="{sanitizar(usuario_actual)}" required>
    <input name="texto" id="textField" class="in-text" type="text" placeholder="Escribe un mensaje..." required autofocus autocomplete="off">
    <button type="submit">➤</button>
  </form>
  <script>
    // Persistencia local del nombre de usuario en el navegador del celular
    const userField = document.getElementById('userField');
    if (userField.value === "" && localStorage.getItem('chat_username')) {{
      userField.value = localStorage.getItem('chat_username');
    }}
    document.getElementById('chatForm').addEventListener('submit', () => {{
      localStorage.setItem('chat_username', userField.value);
    }});
    
    // Polling síncrono automático cada 3 segundos para refrescar el historial
    setTimeout(() => location.reload(), 3000);
  </script>
</body>
</html>"""
    return html

def manejar_peticion(conn):
    """Procesa el flujo de datos TCP/IP y discrimina los métodos GET y POST"""
    global mensajes
    try:
        datos = b""
        conn.settimeout(2.0)
        while True:
            try:
                chunk = conn.recv(512)
                if not chunk: break
                datos += chunk
                if len(datos) > 4096: break # Evitar desbordamiento de búfer
            except OSError: 
                break

        if not datos: return

        # Decodificación y parsing de cabeceras HTTP
        texto = datos.decode("utf-8", "ignore")
        lineas = texto.split("\r\n")
        primera = lineas[0] if lineas else ""
        metodo = primera.split(" ")[0] if " " in primera else "GET"
        ruta   = primera.split(" ")[1] if primera.count(" ") >= 1 else "/"
        usuario_actual = ""

        # Enrutamiento de la petición
        if metodo == "POST" and "/enviar" in ruta:
            body = texto.split("\r\n\r\n", 1)[-1] if "\r\n\r\n" in texto else ""
            params = parsear_post(body)
            usuario = sanitizar(params.get("usuario", "Anonimo"), 20)
            msg_txt = sanitizar(params.get("texto", ""), 200)
            usuario_actual = usuario

            if usuario and msg_txt:
                # Gestión de cola FIFO para control estricto de memoria RAM
                if len(mensajes) >= MAX_MENSAJES:
                    mensajes.pop(0)   
                mensajes.append({"usuario": usuario, "texto": msg_txt, "hora": hora_actual()})
                
                # Destello rápido en placa para indicar procesamiento de datos exitoso
                led_onboard.toggle()
                print(f"[POST] Mensaje recibido de '{usuario}': {msg_txt}")

        elif metodo == "GET" and "/limpiar" in ruta:
            mensajes = []
            print("[ALERTA] Historial de chat vaciado por comando de red.")

        # Envío de respuesta con protocolo estructurado HTTP/1.1
        html = pagina_html(usuario_actual)
        resp = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n" + html
        conn.send(resp.encode("utf-8"))
    except Exception as e:
        print(f"[ERROR] Excepción en la petición: {e}")
    finally:
        conn.close()

def main():
    """Lazo de inicialización y escucha pasiva del socket del servidor"""
    iniciar_ap()
    
    # Crear e instanciar el socket orientado a conexión (Stream)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("", 80)) # Vinculación al puerto estándar HTTP
    s.listen(5)      # Tolerancia de hasta 5 peticiones concurrentes en cola
    s.settimeout(0.3)
    
    print("[SISTEMA] Servidor socket HTTP escuchando en el puerto 80...")
    print("-" * 60)
    
    while True:
        try:
            conn, addr = s.accept()
            manejar_peticion(conn)
        except OSError:
            # Captura el timeout del socket para no bloquear el hilo de ejecución
            pass   

# Ejecución del programa principal
main()