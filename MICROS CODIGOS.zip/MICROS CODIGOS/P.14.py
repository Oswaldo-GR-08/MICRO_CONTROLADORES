# ============================================================================
# Práctica 14: Sistema de Control Síncrono para Cruce Peatonal Coordinado
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import Pin
import time

# --- CONFIGURACIÓN DE HARDWARE ---
# Semáforo Vehicular (LEDs)
V_ROJO = Pin(2, Pin.OUT)
V_AMARILLO = Pin(3, Pin.OUT)
V_VERDE = Pin(4, Pin.OUT)

# Semáforo Peatonal (LEDs)
P_ROJO = Pin(5, Pin.OUT)
P_VERDE = Pin(6, Pin.OUT)

# Pulsador de solicitud de cruce peatonal
PULSADOR_PEATON = Pin(7, Pin.IN, Pin.PULL_DOWN)

# --- VARIABLES DE CONTROL DE FLUJO ---
solicitud_cruce = False

# --- FUNCIÓN PARA CONFIGURAR LOS SEMÁFOROS ---
def set_semaforos(vr, va, vv, pr, pv):
    """Asigna los estados lógicos de manera simultánea a ambos semáforos"""
    V_ROJO.value(vr)
    V_AMARILLO.value(va)
    V_VERDE.value(vv)
    P_ROJO.value(pr)
    P_VERDE.value(pv)

# --- CONFIGURACIÓN DE INTERRUPCIÓN / MONITOREO DEL BOTÓN ---
def verificar_pulsador():
    """Escanea el botón de forma no bloqueante para registrar la demanda"""
    global solicitud_cruce
    if PULSADOR_PEATON.value() == 1 and not solicitud_cruce:
        time.sleep_ms(20)  # Anti-rebote por software
        if PULSADOR_PEATON.value() == 1:
            solicitud_cruce = True
            print("\n[ALERTA] Solicitud de cruce peatonal detectada. Programando transición...")

# Inicialización segura de estados al arrancar
# Vehículos avanzan (Verde) | Peatones esperan (Rojo)
set_semaforos(vr=0, va=0, vv=1, pr=1, pv=0)

print("[SISTEMA] Control de Cruce Peatonal Inicializado.")
print("[ESTADO] Semáforo Vehicular: VERDE | Semáforo Peatonal: ROJO")

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    # --- FASE DEFAULT: Ciclo Normal de Flujo Vehicular ---
    # El semáforo vehicular permanece en VERDE monitoreando constantemente el botón
    # Simulamos un ciclo de tiempo mediante porciones pequeñas para mantener interactividad
    for _ in range(50):  # Ventana de tiempo equivalente de monitoreo activo
        verificar_pulsador()
        time.sleep_ms(100)
    
    # Si durante la fase regular se presionó el botón, se ejecuta la secuencia de cruce
    if solicitud_cruce:
        print("[PROCESO] Iniciando Fase de Transición Segura...")
        
        # 1. Transición Vehicular: Cambio de Verde a Amarillo
        set_semaforos(vr=0, va=1, vv=0, pr=1, pv=0)
        print("[LOG] Vehicular: AMARILLO (Precaución) | Peatonal: ROJO")
        # Ventana de tiempo fija para frenado vehicular
        for _ in range(20):
            time.sleep_ms(100)
            
        # 2. Alto Total Vehicular de Seguridad (Margen preventivo antes de abrir paso peatonal)
        set_semaforos(vr=1, va=0, vv=0, pr=1, pv=0)
        print("[LOG] Vehicular: ROJO (Alto Total) | Peatonal: ROJO")
        time.sleep_ms(500)
        
        # 3. Fase Peatonal Activa y Cuenta Regresiva de 10 segundos
        set_semaforos(vr=1, va=0, vv=0, pr=0, pv=1)
        print("[LOG] Vehicular: ROJO | Peatonal: VERDE (Cruce Permitido)")
        
        # Ejecución del contador descendente síncrono reflejado en la consola
        for tiempo in range(10, 0, -1):
            print(f"[CUENTA REGRESIVA] Tiempo disponible para cruzar: {tiempo} segundos...")
            time.sleep_ms(1000)
            
        print("[PROCESO] Fin del tiempo de cruce. Restableciendo vialidad...")
        
        # 4. Transición Peatonal: Advertencia de cierre (Parpadeo rápido del rojo peatonal)
        for _ in range(3):
            set_semaforos(vr=1, va=0, vv=0, pr=1, pv=0)
            time.sleep_ms(250)
            set_semaforos(vr=1, va=0, vv=0, pr=0, pv=0)
            time.sleep_ms(250)
            
        # 5. Regreso ordenado al estado por defecto
        solicitud_cruce = False
        set_semaforos(vr=0, va=0, vv=1, pr=1, pv=0)
        print("[ESTADO] Semáforo Vehicular: VERDE | Semáforo Peatonal: ROJO\n")