# ============================================================================
# Práctica 16: Control inteligente de iluminación mediante Bluetooth
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

import machine
import bluetooth
import time
from micropython import const

# --- CONFIGURACIÓN DE HARDWARE ---
RELAY_PIN = 15  # Pin GPIO conectado a la base del transistor 2N2222A
LDR_PIN = 26    # Pin ADC0 utilizado para leer la fotorresistencia

relay = machine.Pin(RELAY_PIN, machine.Pin.OUT)
ldr = machine.ADC(LDR_PIN)

# --- VARIABLES DE CONTROL DE ESTADO ---
# Modos: 0 = Manual, 1 = Temporizador, 2 = Automático (LDR)
current_mode = 0  
timer_duration = 0
timer_start_time = 0
ldr_threshold = 30000  # Umbral de oscuridad (Ajustable de 0 a 65535)

# --- CONFIGURACIÓN BLUETOOTH BLE (Nordic UART Service) ---
_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

# UUIDs Estándar para emulación de puerto Serie/UART por BLE
UART_UUID = bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
RX_UUID = bluetooth.UUID("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
TX_UUID = bluetooth.UUID("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

UART_SERVICE = (
    UART_UUID,
    (
        (RX_UUID, _FLAG_WRITE),
        (TX_UUID, _FLAG_NOTIFY),
    ),
)

class BLEUart:
    def __init__(self, ble, name="PicoW_Lighting"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        ((self._rx_handle, self._tx_handle),) = self._ble.gatts_register_services((UART_SERVICE,))
        self._connections = set()
        self._write_callback = None
        self._advertise(name)

    def _irq(self, event, data):
        if event == _IRQ_CENTRAL_CONNECT:
            conn_handle, _, _ = data
            self._connections.add(conn_handle)
            print("[BLE] Dispositivo móvil conectado.")
        elif event == _IRQ_CENTRAL_DISCONNECT:
            conn_handle, _, _ = data
            if conn_handle in self._connections:
                self._connections.remove(conn_handle)
            print("[BLE] Dispositivo móvil desconectado.")
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            if value_handle == self._rx_handle and self._write_callback:
                data = self._ble.gatts_read(self._rx_handle).decode("utf-8").strip()
                self._write_callback(data)

    def send(self, data):
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._tx_handle, data + "\n")

    def _advertise(self, name="PicoW_Lighting"):
        payload = bytearray(b"\x02\x01\x06") + bytearray([len(name) + 1, 0x09]) + name.encode()
        self._ble.gap_advertise(100000, adv_data=payload)
        print(f"[BLE] Anunciando dispositivo como: {name}")

    def on_write(self, callback):
        self._write_callback = callback


# --- PROCESAMIENTO DE COMANDOS RECIBIDOS ---
def handle_ble_command(command):
    global current_mode, timer_duration, timer_start_time
    print(f"[COMANDO] Recibido desde la App: {command}")
    
    # 1. Procesar Modo Manual
    if command == "ON":
        current_mode = 0
        relay.value(1)
        ble_uart.send("STATUS:ON")
        print("[MODO] Manual - Bombillo Encendido")
        
    elif command == "OFF":
        current_mode = 0
        relay.value(0)
        ble_uart.send("STATUS:OFF")
        print("[MODO] Manual - Bombillo Apagado")
        
    # 2. Procesar Modo Automático (LDR)
    elif command == "AUTO_ON":
        current_mode = 2
        print("[MODO] Automático Activado (LDR)")
        ble_uart.send("MODE:AUTO")
        
    elif command == "AUTO_OFF":
        current_mode = 0
        relay.value(0)
        print("[MODO] Automático Desactivado")
        ble_uart.send("STATUS:OFF")
        
    # 3. Procesar Modo Temporizador (Formato esperado -> T:segundos, ej. T:10 o T:60)
    elif command.startswith("T:"):
        try:
            seconds = int(command.split(":")[1])
            if seconds > 0:
                current_mode = 1
                timer_duration = seconds
                timer_start_time = time.time()
                relay.value(1)
                print(f"[MODO] Temporizador iniciado por {seconds} segundos")
                ble_uart.send(f"TIMER:{seconds}")
        except ValueError:
            print("[ERROR] Comando de temporizador no válido")


# --- INICIALIZACIÓN DEL SISTEMA ---
ble = bluetooth.BLE()
ble_uart = BLEUart(ble)
ble_uart.on_write(handle_ble_command)

print("[SISTEMA] Listo. Esperando control...")
relay.value(0) # Inicia apagado por seguridad

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
last_feedback_time = time.time()

while True:
    current_time = time.time()
    
    # LÓGICA DEL MODO TEMPORIZADOR
    if current_mode == 1:
        elapsed = current_time - timer_start_time
        remaining = timer_duration - elapsed
        
        if remaining <= 0:
            relay.value(0)
            current_mode = 0
            print("[TEMPORIZADOR] Tiempo agotado. Bombillo apagado.")
            ble_uart.send("STATUS:OFF")
            ble_uart.send("COUNTDOWN:0")
        else:
            # Enviar la cuenta regresiva a la aplicación cada segundo
            if current_time - last_feedback_time >= 1:
                ble_uart.send(f"COUNTDOWN:{int(remaining)}")
                last_feedback_time = current_time

    # LÓGICA DEL MODO AUTOMÁTICO (LDR)
    elif current_mode == 2:
        # Lectura del ADC de 16 bits (0 - 65535)
        ldr_value = ldr.read_u16() 
        
        # Dependiendo de cómo se conecte la resistencia limitadora:
        # Si la lectura disminuye con la oscuridad, se activa al bajar del umbral.
        if ldr_value < ldr_threshold:
            if relay.value() == 0:
                relay.value(1)
                print(f"[AUTO] Oscuridad detectada ({ldr_value}). Bombillo ON.")
                ble_uart.send("STATUS:ON")
        else:
            if relay.value() == 1:
                relay.value(0)
                print(f"[AUTO] Luz suficiente detectada ({ldr_value}). Bombillo OFF.")
                ble_uart.send("STATUS:OFF")
                
        # Enviar el estado del sensor de manera periódica
        if current_time - last_feedback_time >= 2:
            ble_uart.send(f"LDR:{ldr_value}")
            last_feedback_time = current_time

    time.sleep_ms(100)