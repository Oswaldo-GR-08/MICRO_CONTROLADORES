# ============================================================================
# Práctica 15: Cliente BLE (Central) - Escaneo y Consumo de Servicio
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

import bluetooth
import aioble
import asyncio
import time

# --- MISMOS IDENTIFICADORES DEL SERVIDOR ---
_SERVICIO_UUID = bluetooth.UUID("19b10000-e8f2-537e-4f6c-d104768a1214")
_CHAR_UUID = bluetooth.UUID("19b10001-e8f2-537e-4f6c-d104768a1214")
NOMBRE_OBJETIVO = "PicoW_Servidor_OGRI"

async def tarea_cliente():
    print("[SISTEMA] Cliente BLE Inicializado. Iniciando escaneo de dispositivos...")
    dispositivo_encontrado = None

    # 1. ESCANEAR DISPOSITIVOS EN EL RANGO
    async with aioble.scan(5000, interval_us=30000, window_us=30000) as escáner:
        async for resultado in escáner:
            if resultado.name() == NOMBRE_OBJETIVO:
                dispositivo_encontrado = resultado.device
                print(f"[ÉXITO] Servidor detectado: {resultado.name()} [{resultado.device}]")
                break

    if not dispositivo_encontrado:
        print("[ERROR] No se encontró el servidor objetivo. Reinicia el script para reintentar.")
        return

    # 2. INTENTAR CONEXIÓN CON EL PERIPHERAL
    try:
        print(f"[CONEXIÓN] Estableciendo enlace con {NOMBRE_OBJETIVO}...")
        conexion = await dispositivo_encontrado.connect()
        print("[CONEXIÓN] Enlace establecido de manera segura.")
    except asyncio.TimeoutError:
        print("[ERROR] Tiempo de espera agotado al intentar conectar.")
        return

    async with conexion:
        try:
            # 3. BUSCAR EL SERVICIO Y LA CARACTERÍSTICA ESPECÍFICA
            servicio = await conexion.service(_SERVICIO_UUID)
            caracteristica = await servicio.characteristic(_CHAR_UUID)
            
            # 4. ENVIAR DATOS Y LEER RESPUESTA (CICLO DE PRUEBA)
            for i in range(1, 6):
                mensaje_envio = f"Mensaje_{i}_OGRI"
                print(f"\n[TX] Enviando al servidor: '{mensaje_envio}'")
                
                # Escritura remota en la característica del servidor
                await caracteristica.write(mensaje_envio.encode('utf-8'))
                
                # Pequeña pausa para el procesamiento del servidor
                await asyncio.sleep(0.5)
                
                # Leer la respuesta devuelta por el servidor
                dato_recibido = await caracteristica.read()
                print(f"[RX] Respuesta del servidor: '{dato_recibido.decode('utf-8')}'")
                
                await asyncio.sleep(2) # Espera de 2 segundos antes de la siguiente trama
                
        except Exception as e:
            print(f"[ERROR] Ocurrió una falla durante la comunicación: {e}")
            
    print("\n[SISTEMA] Tareas concluidas. Conexión cerrada de forma ordenada.")

# Ejecutar el lazo asíncronico principal
asyncio.run(tarea_cliente())