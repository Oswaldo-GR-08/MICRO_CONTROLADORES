# ============================================================================
# Práctica 8: Contador Decimal (0-9) con Display de 7 Segmentos y Pull-up Interno
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

from machine import Pin
import time

# --- CONFIGURACIÓN DE HARDWARE ---
# Mapeo de segmentos del display a los pines GPIO de la Pico W:
# Segmentos:      A,  B,  C,  D,  E,  F,  G
PINES_SEGMENTOS = [2,  3,  4,  5,  6,  7,  8]
segmentos = [Pin(pin, Pin.OUT) for pin in PINES_SEGMENTOS]

# Pulsador configurado con resistencia PULL_UP interna activa.
# En esta configuración, el pin lee '1' en reposo y '0' cuando se presiona.
BUTTON_PIN = 9
pulsador = Pin(BUTTON_PIN, Pin.IN, Pin.PULL_UP)

# --- MATRIZ DE DECODIFICACIÓN (Hexadecimal a 7 Segmentos - Cátodo Común) ---
# Cada posición representa los segmentos [A, B, C, D, E, F, G] para formar el número (0-9)
# 1 = Encendido (3.3V), 0 = Apagado (0V)
NUMEROS_7SEG = [
    [1, 1, 1, 1, 1, 1, 0],  # 0
    [0, 1, 1, 0, 0, 0, 0],  # 1
    [1, 1, 0, 1, 1, 0, 1],  # 2
    [1, 1, 1, 1, 0, 0, 1],  # 3
    [0, 1, 1, 0, 0, 1, 1],  # 4
    [1, 0, 1, 1, 0, 1, 1],  # 5
    [1, 0, 1, 1, 1, 1, 1],  # 6
    [1, 1, 1, 0, 0, 0, 0],  # 7
    [1, 1, 1, 1, 1, 1, 1],  # 8
    [1, 1, 1, 1, 0, 1, 1]   # 9
]

# --- VARIABLES DE CONTROL ---
contador = 0
ultimo_estado_boton = 1 # Inicia en 1 debido a la resistencia Pull-up

# --- FUNCIÓN PARA MOSTRAR EL DÍGITO ---
def actualizar_display(digito):
    """Escribe la máscara correspondiente de segmentos de forma simultánea"""
    mapa_bits = NUMEROS_7SEG[digito]
    for i in range(7):
        segmentos[i].value(mapa_bits[i])

# Inicializar mostrando el número 0
actualizar_display(contador)

print("[SISTEMA] Inicializado correctamente.")
print("[INFO] Resistencia Pull-up interna activada por software.")
print("[INFO] Contador decimal listo en 0. Presiona el pulsador para incrementar.")

# --- BUCLE PRINCIPAL DE EJECUCIÓN ---
while True:
    estado_actual_boton = pulsador.value()
    
    # Detectar flanco de bajada (Transición de reposo '1' a presionado '0')
    if estado_actual_boton == 0 and ultimo_estado_boton == 1:
        
        # --- CONTROL DE REBOTES (DEBOUNCE) ---
        time.sleep_ms(20) # Pausa para filtrar el ruido mecánico del pulsador
        if pulsador.value() == 0: # Confirmar si el botón sigue presionado
            
            contador += 1  # Incrementar la cuenta decimal
            
            # Validación del límite del contador (0 a 9)
            # Al superar el 9, se reinicia automáticamente a 0
            if contador > 9:
                contador = 0
                
            print(f"[CONTEO] Dígito actual en Display: {contador}")
            actualizar_display(contador)
            
            # Bloqueo de ciclo: espera a que el usuario suelte el botón
            while pulsador.value() == 0:
                time.sleep_ms(10)
                
    # Actualizar el registro del último estado del botón
    ultimo_estado_boton = estado_actual_boton
    time.sleep_ms(10)