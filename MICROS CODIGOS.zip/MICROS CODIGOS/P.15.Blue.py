# ============================================================================
# Práctica 15: Servidor BLE (Peripheral) - Transmisión Inalámbrica
# Desarrollado por: OGRI
# Plataforma: Raspberry Pi Pico W (MicroPython)
# ============================================================================

import bluetooth
import aioble
import asyncio

# --- CONFIGURACIÓN DE IDENTIFICADORES ÚNICOS (UUID) ---
# UUIDs aleatorios de 128-bits para el Servicio y la Característica
_SERVICIO_UUID = bluetooth.UUID("19b10000-e8f2-537e-4f6c-d104768a1214")
_CHAR_UUID = bluetooth.UUID("19b10001-e8f2-537e-4f6c-d104768a1214")

# Nombre del dispositivo que se mostrará al escanear
NOMBRE_DISPOSITIVO = "PicoW_Servidor_OGRI"

# --- INICIALIZACIÓN DEL SERVICIO ---
servicio_control = aioble.Service(_SERVICIO_UUID)
char_datos = aioble.Characteristic(
    servicio_control, 
    _CHAR_UUID, 
    read=True, 
    write=True, 
    capture=True
)

async def tarea_servidor():
    print(f"[SISTEMA] Servidor BLE Inicializado y anunciando... (OGRI)")
    
    while True:
        # Registrar y comenzar los anuncios de presencia en el espectro
        async with await aioble.advertise(
            250000, # Intervalo de anuncio en microsegundos (250ms)
            name=NOMBRE_DISPOSITIVO,
            services=[_SERVICIO_UUID],
            appearance=0x0000
        ) as conexion:
            
            print(f"[CONEXIÓN] Cliente conectado exitosamente desde: {conexion.device}")
            
            # Mantener la conexión activa y escuchar peticiones de escritura
            while conexion.is_connected():
                try:
                    # Esperar de forma asíncrona a que el cliente escriba un dato
                    conn_caract, dato = await char_datos.written()
                    mensaje = dato.decode('utf-8').strip()
                    print(f"[RECEPCIÓN] Comando recibido del cliente: '{mensaje}'")
                    
                    # Confirmación de eco enviando una respuesta
                    char_datos.write(f"ACK: {mensaje}".encode('utf-8'))
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    print(f"[INFO] Error o desconexión en transferencia: {e}")
                    break
                    
            print("[CONEXIÓN] Cliente desconectado. Reiniciando anuncios...\n")

# Ejecutar el lazo asíncronico principal
asyncio.run(tarea_servidor())